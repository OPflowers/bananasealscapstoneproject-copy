/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>

/* Project Includes */
#include "TimerA1.h"
// Pointer to user function that gets called on timer interrupt
void (*SetInterrupt)(void);


// Initializes Timer A1 in up mode and triggers a periodic interrupt at a desired frequency
//upmode config
Timer_A_UpModeConfig upModeConfig =
    {
     TIMER_A_CLOCKSOURCE_SMCLK,
     TIMER_A_CLOCKSOURCE_DIVIDER_24,
     500000,
     TIMER_A_TAIE_INTERRUPT_ENABLE,
     TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,
     TIMER_A_DO_CLEAR,
    };
void TimerA1_Init(void(*task)(void), uint16_t period){

    //PCM_setCoreVoltageLevel(PCM_VCORE1);//right core?
    //CS_setExternalClockSourceFrequency(0, CLK_FREQ);
    //CS_initClockSignal(CS_SMCLK, CS_HFXTCLK_SELECT, CS_CLOCK_DIVIDER_1);
    //CS_startHFXT(false); //start HFXT for SMCLK

    //Clock_init();

    SetInterrupt = task;
    upModeConfig.timerPeriod = period;//change timer period in config
    Timer_A_configureUpMode(TIMER_A1_BASE, &upModeConfig); //configure up mode according to config set above
    //Timer_A_enableCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0);
    Interrupt_enableInterrupt(INT_TA1_0); //enable interrupts
    //Interrupt_setPriority(INT_TA1_0, 4 << 5);
    Timer_A_startCounter(TIMER_A1_BASE, TIMER_A_UP_MODE); //start timer
    Timer_A_clearInterruptFlag(TIMER_A1_BASE);
    Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0); //clear interrupt flag

}

// stops Timer A1
void TimerA1_Stop(void){
    //timer A has 15 bits, use bits 5 and 4 for changing mode
    //stop mode is 00

    uint16_t stopMask = 0xFFCF; //this is 65487 in decimal, which is max value of uint16_t - 32 (bit 5) - 16 (bit 4)
    TA1CTL = TA1CTL & stopMask;
}

// ISR function for Timer A1 periodic interrupt
void TA1_0_IRQHandler(void){

    (*SetInterrupt)();
    Timer_A_clearInterruptFlag(TIMER_A1_BASE);
    Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE, TIMER_A_CAPTURECOMPARE_REGISTER_0); //clear interrupt flag
}
