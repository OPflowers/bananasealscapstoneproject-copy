/*
 * tft_data.h
 *
 *  Created on: Nov 18, 2021
 *      Author: justi
 */

#ifndef TFT_DATA_H_
#define TFT_DATA_H_


#if defined (__AVR__)
    #include <avr/pgmspace.h>
#else
    #if !defined(PROGMEM)
        #define PROGMEM
    #endif
#endif

extern const uint8_t logo[239] PROGMEM;
extern const uint8_t pic[3205] PROGMEM;
extern const uint8_t flash[12753] PROGMEM;


#endif /* TFT_DATA_H_ */
