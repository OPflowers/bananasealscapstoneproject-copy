/*
 * Defines.h
 *
 *  Created on: Oct 6, 2021
 *      Author: justi
 */

#ifndef DEFINES_H_
#define DEFINES_H_

#define RED     0xff0000UL
#define ORANGE  0xffa500UL
#define GREEN   0x00ff00UL
#define BLUE    0x0000ffUL
#define BLUE_1  0x5dade2L
#define YELLOW  0xffff00UL
#define PINK    0xff00ffUL
#define PURPLE  0x800080UL
#define WHITE   0xffffffUL
#define BLACK   0x000000UL

#define CLK_FREQ 12000000 //12MHz

#define NUMBER_OF_TASKS 2 //number of tasks currently implemented
#define NUMBER_OF_LETTERS 5 //number of letter slots
#define NUMBER_OF_CHANNELS 5 //number of select lines on a multiplexer

//unused
#define SENSOR_INPUT_BUFFER_BASE   3
#define SENSOR_INPUT_BUFFER_LENGTH (0x01 << SENSOR_INPUT_BUFFER_BASE)
#define ADC14_CONVERSION_START_ADDR(REG)    (uint32_t)((REG<<ADC14_CTL1_CSTARTADD_OFS) & ADC14_CTL1_CSTARTADD_MASK)

#define NUMBER_OF_HALL_SENSORS 5 //number of sensors per letter block
#define Ts_HALL_SENSORS 2 //task frequency of hall sensor task scheduler

#define LETTER_THRESHOLD_HIGH_LOW 0
#define LETTER_THRESHOLD_LOW 5000 //placeholder for ADC conversion of low voltage from hall sensor
#define LETTER_THRESHOLD_HIGH_HIGH 6000 //placeholder for ADC conversion of high voltage from hall sensor

//ADC channel definitions
#define LETTER_SENSOR_1_CHANNEL ADC_INPUT_A15
#define LETTER_SENSOR_2_CHANNEL ADC_INPUT_A14
#define LETTER_SENSOR_3_CHANNEL ADC_INPUT_A9
#define LETTER_SENSOR_4_CHANNEL ADC_INPUT_A8
#define LETTER_SENSOR_5_CHANNEL ADC_INPUT_A6

//ADC memory index definitions
#define LETTER_SENSOR_1_INDEX ADC_MEM2
#define LETTER_SENSOR_2_INDEX ADC_MEM3
#define LETTER_SENSOR_3_INDEX ADC_MEM4
#define LETTER_SENSOR_4_INDEX ADC_MEM5
#define LETTER_SENSOR_5_INDEX ADC_MEM6

//ADC port definitions
#define LETTER_SENSOR_1_PORT GPIO_PORT_P6
#define LETTER_SENSOR_2_PORT GPIO_PORT_P6
#define LETTER_SENSOR_3_PORT GPIO_PORT_P4
#define LETTER_SENSOR_4_PORT GPIO_PORT_P4
#define LETTER_SENSOR_5_PORT GPIO_PORT_P4

//ADC pin definition
#define LETTER_SENSOR_1_PIN GPIO_PIN0
#define LETTER_SENSOR_2_PIN GPIO_PIN1
#define LETTER_SENSOR_3_PIN GPIO_PIN4
#define LETTER_SENSOR_4_PIN GPIO_PIN5
#define LETTER_SENSOR_5_PIN GPIO_PIN7

//multiplexer chip select
#define MULTIPLEXER_CS1_PORT GPIO_PORT_P2 //CS ports definition
#define MULTIPLEXER_CS1_PIN GPIO_PIN4 //CS pin definition

#define MULTIPLEXER_CS2_PORT GPIO_PORT_P2 //CS ports definition
#define MULTIPLEXER_CS2_PIN GPIO_PIN6 //CS pin definition

#define MULTIPLEXER_CS3_PORT GPIO_PORT_P2 //CS ports definition
#define MULTIPLEXER_CS3_PIN GPIO_PIN7 //CS pin definition

#define MULTIPLEXER_CS4_PORT GPIO_PORT_P2 //CS ports definition
#define MULTIPLEXER_CS4_PIN GPIO_PIN3 //CS pin definition

#define MULTIPLEXER_CS5_PORT GPIO_PORT_P3 //CS ports definition
#define MULTIPLEXER_CS5_PIN GPIO_PIN5 //CS pin definition

//multiplexer data line
#define MULTIPLEXER_DATA_PORT GPIO_PORT_P3 //DATA port definition
#define MULTIPLEXER_DATA_PIN GPIO_PIN7 //DATA pin definition

//clock line
#define CLOCK_LINE_PORT GPIO_PORT_P1 //CLK port definition
#define CLOCK_LINE_PIN GPIO_PIN5 //CLK pin definition

//LCD connections for SPI

//SCK (clock) definitions
#define LCD_SCK_PORT GPIO_PORT_P1
#define LCD_SCK_PIN GPIO_PIN5

//Master in, slave out (MISO) definitions.
//This refers "master" as the MCU.
#define LCD_MISO_PORT GPIO_PORT_P1
#define LCD_MISO_PIN GPIO_PIN7

//Master out, slave in (MOSI) definitions.
//This refers "master" as the MCU.
#define LCD_MOSI_PORT GPIO_PORT_P1
#define LCD_MOSI_PIN GPIO_PIN6

//Chip select definitions
#define LCD_CS_PORT GPIO_PORT_P5
#define LCD_CS_PIN GPIO_PIN0

//LCD power down definitions
#define LCD_PD_PORT GPIO_PORT_P5
#define LCD_PD_PIN GPIO_PIN6

//LCD display states
#define TFT_DEFAULT 0
#define TFT_DISPLAY_WRONG 1
#define TFT_DISPLAY_RIGHT 2

//LCD highlighting of text, hardcoded values
#define TFT_HIGHLIGHT_HEIGHT 16
#define TFT_HIGHLIGHT_COMPACTNESS_OFFSET 8 //var for tight the highlighting is


#define BUFFER_SIZE 8000 //circular buffer size

#define PARAM_FLASH_ADDR 0x3F000 //Bank 0, sector 27 address of MSP432

#define IMAGE_FLASH_ADDR 0x20000 //Bank 1, sector 0 address of MSP432

#define SECTOR_SIZE 0x1000 //4KB, size of one sector

//max number of images in MSP432 flash in one memory bank, given max size of image is 8kb
#define NUM_IMAGES 15

#define NUM_SECTORS 32

#define NUM_ASCII_FONTS 128
//font used on TFT
#define FONT 31
//debug var for testing code
#define DEBUG 0

#define IMAGE_TYPE_SIZE 5 //5 bytes
#define IMAGE_WORD_SIZE 6 //6 bytes

#define IMAGE_STORAGE_SIZE 0x2000
//19 bytes for parameters total
typedef struct {
    uint16_t height; //2 bytes
    uint16_t width; //2 bytes
    uint32_t image_size; //4 bytes
    char image_type[5]; //5 bytes
    char image_word[6]; //6 bytes
    uint8_t* image;
}image_properties_t;

#define IMAGE_PARAM_BYTES 19

#endif /* DEFINES_H_ */
