
#include "FSM.h"

/*
 * Initialize FSM
 *
 * Parameter: value
 * This represents the FSM's ID and the game's current string and correct string.
 *
 * Params: FSMType pointer, uint32_t
 */
void InitializeFSM(FSMType *FSM, uint32_t value)
{
    FSM->value = value;
    FSM->CurrentString = "";
    FSM->CorrectString = "";
}

/*
 * Initialize Hall Sensors
 *
 * Params:
 * HallSensorType *HallSensor: a pointer to the hall sensor to be initialized
 * uint32_t AnalogChannel: The ADC channel of the hall sensor.
 *  Defined in datasheet, specified in "Defines.h" for each hall sensor.
 * uint32_t ADCMemoryIndex: The memory index for ADC readings to be stored in.
 *  Defined in datasheet, specified in "Defines.h" for each hall sensor.
 * uint32_t SensorID: The ID number for the hall sensor.
 */
void InitializeHallSensor(HallSensorType *HallSensor, uint32_t AnalogChannel,
                          uint32_t ADCMemoryIndex, uint32_t SensorID)
{
    InitializeFSM((FSMType *) HallSensor, SensorID);
    HallSensor->AnalogChannel = AnalogChannel;
    HallSensor->ADCMemoryIndex = ADCMemoryIndex;
    HallSensor->CumulativeSum = 0;
    HallSensor->SensorAverage = 0;
    HallSensor->BufferIndex = 0;
    HallSensor->LetterIndex = 0;
    HallSensor->CycleComplete = false;
    HallSensor->CurrentLetter = ' ';
    uint32_t i;
    for(i = 0; i < SENSOR_INPUT_BUFFER_LENGTH; i++){
        HallSensor->SensorInputBuffer[i] = 0;
        HallSensor->Reading[i] = 0;
    }
}
//--------------------------------------------------------------------------
// Determine next FSM state
//--------------------------------------------------------------------------
void NextStateFunction(FSMType *FSM)
{

}

//--------------------------------------------------------------------------
// Determine LED output based on state
//--------------------------------------------------------------------------
void OutputFunction(FSMType *FSM)
{


}

