/*
 * tft.h
 *
 *  Created on: Nov 19, 2021
 *      Author: justi
 */

#ifndef TFT_H_
#define TFT_H_

#include "Defines.h"

void TFT_init(void);
void TFT_get_font_widths(int font);
void TFT_get_existing_images();
void TFT_clear_image(int size);
void TFT_flash_finished();
void TFT_flash_image(uint16_t height, uint16_t width, uint32_t image_size, char image_type[5], char word[6], uint8_t image_array[], int sector_index);
image_properties_t TFT_get_image_params(int index);
void TFT_set_display_default();
void TFT_update_words(char* CurrentString);
void TFT_touch_init(void);
int TFT_touch(void);
void TFT_load_image(void);
void TFT_load_image_with_array(uint8_t image_array[], int size);
void TFT_check_words(void);
void TFT_display(void);
void TFT_recalibrate(void);


#endif /* TFT_H_ */
