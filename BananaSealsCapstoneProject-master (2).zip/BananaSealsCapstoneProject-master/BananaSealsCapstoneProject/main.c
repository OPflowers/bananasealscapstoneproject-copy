/*
 * main.c
 *
 *  Created on: Nov 19, 2021
 *      Author: Justin Guo
 */
/* DriverLib Include */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Library Includes */
#include "UART0.h"
#include "Defines.h"
#include "Tasks.h"
#include "Clock.h"
#include "TimerA1.h"

/* EVE Driver Includes */
#include "EVE_commands.h"
#include "tft_data.h"
#include "tft.h"

//array of letters - first index is for empty space
const char letter_array[] = { ' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
		'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
		'X', 'Y', 'Z' };

//definition for the multiplexer chip select ports
const uint32_t multiplexer_cs_ports[] = { MULTIPLEXER_CS1_PORT,
MULTIPLEXER_CS2_PORT,
MULTIPLEXER_CS3_PORT,
MULTIPLEXER_CS4_PORT,
MULTIPLEXER_CS5_PORT };

//definition for the multiplexer pin select ports
const uint32_t multiplexer_cs_pins[] = { MULTIPLEXER_CS1_PIN,
MULTIPLEXER_CS2_PIN,
MULTIPLEXER_CS3_PIN,
MULTIPLEXER_CS4_PIN,
MULTIPLEXER_CS5_PIN };

//definition for the list of flash sectors stored into an array
const int sector_array[NUM_SECTORS] = { FLASH_SECTOR0, FLASH_SECTOR1,
		FLASH_SECTOR2, FLASH_SECTOR3,
		FLASH_SECTOR4, FLASH_SECTOR5, FLASH_SECTOR6, FLASH_SECTOR7,
		FLASH_SECTOR8, FLASH_SECTOR9, FLASH_SECTOR10, FLASH_SECTOR11,
		FLASH_SECTOR12, FLASH_SECTOR13, FLASH_SECTOR14, FLASH_SECTOR15,
		FLASH_SECTOR16, FLASH_SECTOR17, FLASH_SECTOR18, FLASH_SECTOR19,
		FLASH_SECTOR20, FLASH_SECTOR21, FLASH_SECTOR22, FLASH_SECTOR23,
		FLASH_SECTOR24, FLASH_SECTOR25, FLASH_SECTOR26, FLASH_SECTOR27,
		FLASH_SECTOR28, FLASH_SECTOR29, FLASH_SECTOR30, FLASH_SECTOR31 };

//array storing Letter Sensor slots
HallSensorType HallSensors[NUMBER_OF_HALL_SENSORS];

/*
 * UART configuration for communication with the Javascript website.
 *
 * Clock Source: SMCLK (12MHz)
 * Baud rate division: 78
 * First modulation stage register setting: 2, obtained from Technical manual
 * Second modulation stage register setting: 0, obtained from Technical manual
 * Parity: None
 * First bit: Least significant bit
 * Number of stop bits: one
 * Uart mode: default
 * Sampling: enable oversampling
 */
const eUSCI_UART_ConfigV1 uartConfig = {
EUSCI_A_UART_CLOCKSOURCE_SMCLK,          // SMCLK Clock Source
		78,                                     // BRDIV = 78
		2,                                       // UCxBRF = 2
		0,                                       // UCxBRS = 0
		EUSCI_A_UART_NO_PARITY,                  // No Parity
		EUSCI_A_UART_LSB_FIRST,                  // LSB First
		EUSCI_A_UART_ONE_STOP_BIT,               // One stop bit
		EUSCI_A_UART_MODE,                       // UART mode
		EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION  // Oversampling
		};

/*
 * Method definitions
 */

//Initialization Functions
void TaskFunction_HallSensors(FSMType*);
void TaskFunction_LCD(FSMType*);
void ReadHallSensors(HallSensorType *HallSensor);
void InitializeLCDPins(void);
void InitializeADC_HallSensors(void);
void InitializeHallSensors(void);

//Multiplexer functions
void InitializeMultiplexerPins(void);
void StartMultiplexer(void);
void ToggleMultiplexerSelect();
uint32_t ReadMultiplexerOutput(HallSensorType *HallSensor);
void StopMultiplexer(void);

//UART functions
void writeToBuffer(uint8_t data_element, int head);
void readFromBuffer(int tail);
void processItem(uint8_t base);

//Game State definitions
FSMType LCD; //FSMType to feed into task scheduler
FSMType GameState; //stores current word read by multiplexers

//Task array definition
TaskType Tasks[NUMBER_OF_TASKS] = { { &TaskFunction_HallSensors, 0, 1,
		(FSMType*) &HallSensors[0] }, { &TaskFunction_LCD, 0, Ts_HALL_SENSORS,
		(FSMType*) &LCD } };

//global variables

//mutex for if the UART IRQ is receiving data
//blocks all other methods if this is true
bool b_updating_images = false;

//mutex for if the LCD screen needs to be updated
//blocks multiplexer reading as P1.5 needs to be used for the SPI clock
bool b_multiplexers_disabled = true;

//task function counter for the LCD; does not display every iteration
int g_lcd_task_function_counter = 0;

//debug variable
int euscia0_count = 0;

/*
 * UART code
 */

uint8_t base; //holds variable read from the UART IRQ

//circular buffer
uint8_t data[BUFFER_SIZE];
int head = 0;
int tail = 0;
uint8_t contentFlag = 0;

uint8_t dictionaryIndex = 0; //index of images, also represents the number of images read so far
uint32_t dest = 0x00020000; //destination address of the images to flash in MSP432
image_properties_t dictionary[NUM_IMAGES]; //list of images and their properties on the system

/*
 * Function that writes the data received into the circular buffer [data].
 */
void
/*
 * Called by:
 *  processBuffer() in main.c
 * Calls:
 *  none
 * Blocks: none
 * Input: uint8_t, int
 * Bytes used on the stack: 0
 * Returns: none
 */
writeToBuffer(uint8_t data_element, int head) {
	data[head] = data_element;
}

/*
 * Buffer variables holding parameter information on images
 *
 * These variable hold information sent as characters, so
 * buffers need to be created to convert them into their respective
 * numerical values.
 *
 * Ex: numerical value 212 would be sent as {"2", "1", "2"}
 */
char word[6]; //array holding current image's word
int wordIndex = 0; //index for word array

uint8_t image[8000]; //array holding current image's index. This variable holds string values.
int imageIndex = 0; //index for the current image's input values

char imageType[5]; //array holding current image's file type; JS code converts images to "jpeg"
int imageTypeIndex = 0; //index for current image's file type

char imageSizeTemp[5]; //array holding current image's file size
int imageSizeTempIndex = 0; //index for current image's file size
int imageSize = 0; //represents the converted file size

char imageWidthTemp[3]; //array holding current image's width
uint8_t imageWidthTempIndex = 0; //index for current image's width
uint16_t imageWidth = 0; //represents converted width

char imageHeightTemp[3]; //array holding current image's height
uint8_t imageHeightTempIndex = 0; //index for current image's height
uint16_t imageHeight = 0; //represents converted height

//array that holds the actual image numerical values
//this differs from "image" in that "image holds character strings to be converted
uint8_t imageArray[8000];
int imageArrayIndex = 0; //index for the image data

/*
 * Function that reads from "data", the buffer that holds the information send to
 * the MSP via UART, and processes them based on tokens sent.
 *
 * Tokens:
 * "|" -> represents image's word was sent and is now in the buffer
 * "/" -> represents image's image data was sent and is now in the buffer
 * "$" -> represents image's file type was sent and is now in the buffer
 * "*" -> represents image's file size was sent and is now in the buffer
 * "#" -> represents image's width was sent and is now in the buffer
 * "!" -> represents image's height was sent and is now in the buffer
 * "%" -> begin converting image into numerical values to put into imageArray
 */
void
/*
 * Called by:
 *  processBuffer() in main.c
 * Calls:
 *  atoi() in stdlib.c
 *  sizeof()
 * Blocks: none
 * Input: int
 * Bytes used on the stack:
 *  if delimiter is "%": up to 32012 bytes
 *  otherwise: 0
 * Returns: none
 */
readFromBuffer(int tail) {

	//word was received
	if (data[tail] == '|') {
		contentFlag = 1;
	}

	//image data was received
	else if (data[tail] == '/') {
		contentFlag = 2;
	}

	//image type was received
	else if (data[tail] == '$') {
		contentFlag = 3;
	}

	//image size was received
	else if (data[tail] == '*') {
		contentFlag = 4;
	}

	//width was received
	else if (data[tail] == '#') {
		contentFlag = 5;
	}

	//height was received
	else if (data[tail] == '!') {
		contentFlag = 6;
	}

	//begin converting image to numerical values
	else if (data[tail] == '%') {
		contentFlag = 7;
	}

	//handling flags
	if (contentFlag == 1 && data[tail] != '|') {
		word[wordIndex] = data[tail];
		wordIndex++;
	}
	if (contentFlag == 2 && data[tail] != '/') {
		image[imageIndex] = data[tail];
		imageIndex++;
	}
	if (contentFlag == 3 && data[tail] != '$') {
		imageType[imageTypeIndex] = data[tail];
		imageTypeIndex++;
	}
	if (contentFlag == 4 && data[tail] != '*') {
		imageSizeTemp[imageSizeTempIndex] = data[tail];
		imageSizeTempIndex++;
		imageSize = atoi(imageSizeTemp);
	}
	if (contentFlag == 5 && data[tail] != '#') {
		imageWidthTemp[imageWidthTempIndex] = data[tail];
		imageWidthTempIndex++;
		imageWidth = atoi(imageWidthTemp);
	}
	if (contentFlag == 6 && data[tail] != '!') {
		imageHeightTemp[imageHeightTempIndex] = data[tail];
		imageHeightTempIndex++;
		imageHeight = atoi(imageHeightTemp);
	}

	//convert image into numerical values
	if (contentFlag == 7) {
		int i;
		int tempIndex = 0;
		int tempNum;
		imageArrayIndex = 0;

		for (i = 0; i < sizeof(image) / sizeof(image[0]); i++) {
			char temp[4]; //temporary buffer

			//separator between numbers
			if (image[i] != ',') {
				temp[tempIndex] = image[i];
				tempIndex++;
			}

			//null determines end of number
			if (image[i] == ',' || image[i] == NULL) {
				tempNum = atoi(temp); //convert char[] to int
				imageArray[imageArrayIndex] = tempNum; //store converted number
				imageArrayIndex++; //update index

				//reset temporary buffer
				int j;
				for (j = 0; j < 4; j++) {
					temp[j] = NULL;
				}
				tempIndex = 0;
			}
		}
	}
}

/*
 * Function that processes the incoming characters from UART.
 *
 * Calls writeToBuffer() and processItem() on parameter data received
 * and ignores filler data.
 *
 * Filler data, to present the MSP432 from locking out and failing to read certain
 * delimiters, is represented with the "+" delimiter.
 *
 * Sends "k" to the web client to signify the end of transmission as an ACK. This is
 * done when the IRQ handler receives the "." delimiter
 */
void
/*
 * Called by:
 *  EUSCIA0_IRQHandler() in main.c
 * Calls:
 *  writeToBuffer()
 *  readFromBuffer()
 *  TFT_flash_image()
 *  TFT_flash_finished()
 * Blocks: waits on TFT_flash_image to finish its process.
 * Input: uint8_t
 * Bytes used on the stack: up to 8040 bytes
 * Returns: none
 */
processItem(uint8_t base) {

	//done sending images
	if (base == '.') {
		//send ACK to web client to tell it that transmission is done
		UART_transmitData(EUSCI_A0_BASE, 'k');

		//unlock mutex, allows LCD writing and multiplexing operations to start again
		b_updating_images = false;

		//reset index
		dictionaryIndex = 0;

		//toggles b_flash_images_finished in tft.c, signifies flashing is done
		TFT_flash_finished();
		return;
	}

	//received filler data
	if (base == '+') {
		return; //do nothing
	}

	//otherwise, received proper data
	writeToBuffer(base, head); //write data to circular buffer
	readFromBuffer(tail); //read data from circular buffer

	//if full image and its parameters was sent, process them
	if (base == '%') {
		//set image properties

		//create new temporary image buffer; creates a new pointer
		uint8_t temp_image_array[8000];

		int i;
		for (i = 0; i < sizeof(temp_image_array); i++) {
			temp_image_array[i] = imageArray[i]; //store imageArray in the temporary image
		}

		word[wordIndex] = '\0'; //add null terminator to the end of the word
		imageType[imageTypeIndex] = '\0'; //add null terminator to the end of the image type
		imageArray[imageArrayIndex] = '\0'; //add null terminator to the end of the image array

		//create new parameter storage struct
		image_properties_t tempImageProps;

		//store variables
		tempImageProps.height = imageHeight;
		tempImageProps.width = imageWidth;
		tempImageProps.image_size = imageSize;
		strcpy(tempImageProps.image_type, imageType);
		strcpy(tempImageProps.image_word, word);
		tempImageProps.image = temp_image_array;

		//add new struct to dictionary, which is the list of current variables
		dictionary[dictionaryIndex] = tempImageProps;

		//flash image to memory; this method is blocking
		TFT_flash_image(imageHeight, imageWidth, imageSize, imageType, word,
				imageArray, dictionaryIndex);

		//increment or reset dictionaryIndex
		if (dictionaryIndex == NUM_IMAGES) {
			dictionaryIndex = 0;
			dest = 0x00020000;
		} else {
			dictionaryIndex++;
			dest += 0x00001000;
		}

		//reset head and tail
		head = 0;
		tail = 0;

		//clear all temporary buffers

		//clear circular buffer
		int j = 0;
		for (j = 0; j < 8000; j++) {
			data[j] = NULL;
		}

		//clear image string and numerical buffers
		int k;
		for (k = 0; k < 8000; k++) {
			data[k] = NULL;
			image[k] = NULL;
			imageArray[k] = NULL;
		}

		//clear image word buffer
		int t;
		for (t = 0; t < 6; t++) {
			word[t] = NULL;
		}

		wordIndex = 0;

		imageIndex = 0;

		//clear image filetype buffer
		int q;
		for (q = 0; q < 5; q++) {
			imageType[q] = NULL;
			imageSizeTemp[q] = NULL;
		}

		imageTypeIndex = 0;

		imageSizeTempIndex = 0;
		imageSize = 0;

		//clear image width and height buffer
		int y;
		for (y = 0; y < 3; y++) {
			imageWidthTemp[y] = NULL;
			imageHeightTemp[y] = NULL;
		}

		imageWidthTempIndex = 0;
		imageWidth = 0;

		imageHeightTempIndex = 0;
		imageHeight = 0;

		imageArrayIndex = 0;
	} else {
		head++;
		tail++;
	}
}

/*
 * Main function of main.c
 *
 * Calls all of the initialization functions. This includes initialiation for
 * the LCD connection, the timers for the task scheduler, the pins for the ADCs
 * the pins for the multiplexers, and the UART connection for communication with
 * the web service.
 *
 * Is called by default when ran. Has an infinite loop that controls the speed of
 * updating the current input letters.
 *
 *
 */
int
/*
 * Called by:
 *  initcode
 * Calls:
 *  MAP_WDT_A_holdTimer()
 *  ClockInit()
 *  InitializeFSM()
 *  InitializeADC()
 *  InitializeMultiplexerPins()
 *  InitializeLCDPins()
 *  TimerA1_Init()
 *
 *  GPIO_setAsPeripheralModuleFunctionInputPin()
 *  CS_setDCOCenteredFrequency()
 *  UART_initModule()
 *  UART_enableModule()
 *  UART_enableInterrupt()
 *  Interrupt_enableInterrupt()
 *  Interrupt_enableMaster()
 *
 *  ADC_isBusy()
 *  TFT_set_display_default()
 * Blocks:
 *  InitializeLCDPins() calls EVE_Init(), which is blocking if the LCD does not read
 *  the chip identification code correctly or the LCD sends an error message.
 *
 *  ADC_isBusy() is blocking for the time the ADC needs to complete conversion.
 * Input: none
 * Bytes used on the stack: 26 bytes
 * Returns: none
 */main(void) {
	/* Stop Watchdog  */
	MAP_WDT_A_holdTimer();

	//initialization functions
	P1OUT = 0x00; //initialize all pins on P1 to low
	Clock_Init(); //initialize SMCLK to 48MHz
	InitializeFSM(&GameState, 0);
	InitializeADC_HallSensors();
	InitializeMultiplexerPins();
	InitializeLCDPins();
	//init task scheduler
	TimerA1_Init(&TaskSchedulerISR, 300);

	/*
	 * UART initialization
	 */
	GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1,
			GPIO_PIN1 | GPIO_PIN2, GPIO_PRIMARY_MODULE_FUNCTION);

	CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_12);

	UART_initModule(EUSCI_A0_BASE, &uartConfig);
	UART_enableModule(EUSCI_A0_BASE);
	UART_enableInterrupt(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
	Interrupt_enableInterrupt(INT_EUSCIA0);
	Interrupt_enableMaster();

	//disables multiplexer mutex to allow multiplexers funtionality
	b_multiplexers_disabled = false;

	uint32_t i = 0; //loop variable

	//number of times the main while loop has run; controls frequency at which the inputted string is updated
	uint32_t update_counter = 0;

	//skip the first while cycle for updating the number of letters for the previous string. This allows the LCD
	//to update its display when a block is removed or added
	bool skip_first_cycle = true;
	int previous_num_letters = 0; //tracks the number of letters in the previous string
	int current_num_letters = 0; //tracks the number of letters in the current string

	GameState.CorrectString = "BEANS"; //hardcoded word in the event no images were flashed. This is paired with an image of beans.

	while (1) {
		update_counter++;
		if (b_updating_images == false && update_counter >= 10000) {
			while (ADC14_isBusy()) {
			}; //allow ADC to finish conversion
			update_counter = 0;

			//buffer containing the inputted letters, after conversion. Represents word string
			char letter_buffer[NUMBER_OF_HALL_SENSORS + 1];
			int NumLetters = 0;
			char letter;
			for (i = 0; i < NUMBER_OF_HALL_SENSORS; i++) {
				letter = HallSensors[i].CurrentLetter; //get letter from letter slot

				//if the letter is not null, add it to the string
				if (letter != letter_array[0]) {
					letter_buffer[NumLetters] = letter;
					NumLetters++;
				}
			}

			//if the number of letters changed, set the display to remove highlighting
			if (current_num_letters != previous_num_letters) {
				TFT_set_display_default();
			}

			//skip first cycle for updating the previous string's number of letters to set difference
			if (skip_first_cycle) {
				current_num_letters = NumLetters;
				skip_first_cycle = false;
			} else {
				previous_num_letters = current_num_letters;
				current_num_letters = NumLetters;
			}

			letter_buffer[NumLetters] = '\0'; //add null terminator to end of string
			GameState.CurrentString = letter_buffer; //set current input string
		}
	}
}

/*
 * Function executed by the Task Scheduler.
 *
 * 1. Waits for the ADC to finish conversion
 * 2. Loops through the number of channels in the multiplexer (5 lines to read)
 *  a. Starts multiplexer with StartMultiplexer()
 *  b. Toggles multiplexer select line with ToggleMultiplexerSelect()
 *  c. Loops through each sensor:
 *      1. Gets current sensor reading with ReadMultiplexerOutput()
 *      2. Compares the sensor reading distance to high and low thresholds
 *      3. If distance to high threshold is lower, add 2^channel to the
 *          HallSensor's LetterIndex variable
 *          a. Otherwise, negate that bit
 *  d. Stops multiplexer with StopMultiplexer()
 * 3. Toggle ADC conversion again to allow another conversion.
 *
 * This function toggles the data line and loops through each sensor instead of
 * going though each letter slot's sensors once at a time because toggling the line and
 * then setting each letter slot's sensors only requires 5 changes to the data line as
 * opposed to 25, making the method call much faster.
 */
void
/*
 * Called by:
 *  TaskSchedulerISR() in Tasks.c
 * Calls:
 *  ADC14_isBusy()
 *  StartMultiplexer()
 *  ToggleMultiplexerSelect()
 *  ReadMultiplexerOutput()
 *  StopMultiplexer()
 *  ADC14_toggleConversionTrigger()
 * Blocks:
 *  waits for the ADC to finish conversion using ADC14_isBusy()
 *  if UART is sending images, this method returns and does nothing
 *  if the LCD is currently sending info, this method returns and does nothing
 * Input: FSMType*
 * Bytes used on the stack: 14
 * Returns: none
 */
TaskFunction_HallSensors(FSMType *HallSensor) {
	//if currently receiving images from UART, do nothing
	if (b_updating_images == true) {
		return;
	}
	HallSensorType *LocalSensor = (HallSensorType*) HallSensor; //cast to HallSensorType; takes in FSMType

	//check if multiplexer mutex is disabled
	if (b_multiplexers_disabled == false) {

		//toggle clock line and set to low
		GPIO_setAsOutputPin(CLOCK_LINE_PORT, CLOCK_LINE_PIN);
		GPIO_setOutputLowOnPin(CLOCK_LINE_PORT, CLOCK_LINE_PIN);

		int channel_index = 0;
		int hall_sensor_index = 0;

		//loop through each data line (from 0 - 4)
		while (channel_index < NUMBER_OF_CHANNELS) {

			ToggleMultiplexerSelect(channel_index); //toggle data line on multiplexers
			while (ADC14_isBusy()) {
			} //allow ADC to finish conversion
			ADC14_toggleConversionTrigger(); //allow ADC to continue conversions

			hall_sensor_index = 0;

			//loop through each letter slot
			while (hall_sensor_index < NUMBER_OF_HALL_SENSORS) {
				Clock_Delay1us(50); //delay necessary as the index might not update otherwise

				//read multiplexer output
				uint32_t CurrentSensorInput = ReadMultiplexerOutput(
						(LocalSensor + hall_sensor_index));

				//set the sensor's Reading value, mostly for debugging
				(LocalSensor + hall_sensor_index)->Reading[channel_index] =
						CurrentSensorInput;

				//calculate thresholds based on experimental data
				int ThresholdLowDistance = 0, ThresholdHighDistance = 0;
				ThresholdLowDistance = abs(
						CurrentSensorInput - LETTER_THRESHOLD_LOW);

				//accounts for the polarity of the sensors; positive heads towards 2V readings from
				//the hall effect sensors and negative heads towards 0V
				if (abs(CurrentSensorInput - LETTER_THRESHOLD_HIGH_LOW)
						< abs(
								CurrentSensorInput - LETTER_THRESHOLD_HIGH_HIGH)) {
					ThresholdHighDistance = abs(
							CurrentSensorInput - LETTER_THRESHOLD_HIGH_LOW);
				} else {
					ThresholdHighDistance = abs(
							CurrentSensorInput - LETTER_THRESHOLD_HIGH_HIGH);
				}

				//if reading is closer to no magnet read
				if (ThresholdLowDistance < ThresholdHighDistance) {
					uint8_t mask = (0x01 << channel_index);

					//set current letter if it can be indexed into letter_array
					if ((LocalSensor + hall_sensor_index)->LetterIndex < 27) {
						(LocalSensor + hall_sensor_index)->CurrentLetter =
								letter_array[(LocalSensor + hall_sensor_index)->LetterIndex];
					}
					//subtracts the value of 2^channel from the sensor's LetterIndex
					//by negating the bit corresponding to the channel
					(LocalSensor + hall_sensor_index)->LetterIndex &= ~mask;
				} else {
					//adds the value of 2^channel to the sensor's LetterIndex
					//by setting the bit corresponding to the channel to 1
					(LocalSensor + hall_sensor_index)->LetterIndex |= (0x01
							<< channel_index);
				}
				hall_sensor_index = hall_sensor_index + 1;
			}
			channel_index = channel_index + 1;

		}
		//initialize SPI again to high frequency. This is needed to reset the clock line for SPI transmission.
		EVE_SPI_Init_High_Frequency();

	} else {
		//initialize SPI again to high frequency. This is needed to reset the clock line for SPI transmission.
		EVE_SPI_Init_High_Frequency();
	}
}

/*
 * Task function for the LCD display.
 *
 * Updates the state of the current inputted string, checks the tft touch
 * status, and changes the current display.
 */
void
/*
 * Called by:
 *  TaskSchedulerISR() in Tasks.c
 * Calls:
 *  TFT_update_words()
 *  TFT_touch()
 *  TFT_check_words()
 *  TFT_display()
 * Blocks: if the UART is receiving data, this method returns and does nothing
 * Input: FSMType
 * Bytes used on the stack: 0
 * Returns: none
 */
TaskFunction_LCD(FSMType *LCD) {

	if (b_updating_images == false) {
		//disable multiplexer operation. This is because the LCD needs the
		//clock line to send information with SPI.
		b_multiplexers_disabled = true;

		//update the LCD state with the current inputted word
		TFT_update_words(GameState.CurrentString);

		//check the touch state
		if (TFT_touch() == 1) {
			TFT_check_words(); //update highlighting and game state if the touch button was pressed
		}

		//only change the display every 4 iterations of this method call;
		//this allows for faster touch processing as TFT_display() is slow
		g_lcd_task_function_counter++;
		if (g_lcd_task_function_counter >= 3) {
			TFT_display();
			g_lcd_task_function_counter = 0;
		}
		b_multiplexers_disabled = false; //re-enable multiplexer operations
	}
}

/*
 * Set all of the chip select lines of the multiplexers to HIGH
 */
void
/*
 * Called by:
 *  TaskFuncion_HallSensors()
 * Calls:
 *  GPIO_setOutputHighOnPin()
 * Blocks: none
 * Input: none
 * Bytes used on the stack: 4
 * Returns: none
 */
StartMultiplexer() {
	//set all cs pins to high
	if (!b_multiplexers_disabled) {
		int i;
		for (i = 0; i < NUMBER_OF_CHANNELS; i++) {
			GPIO_setOutputHighOnPin(multiplexer_cs_ports[i],
					multiplexer_cs_pins[i]);
		}
	}
}

/*
 * Changes the multiplexer select line to the parameter.
 *
 * This method sends a pseudo generated clock signal made from delays and
 * GPIO toggles to the clock line. The data line is then pulled either
 * HIGH or LOW depending on the input line, which is formatted according to the
 * multiplexer's datasheet.
 *
 * This method assumes that it is being called from TaskFunction_HallSensors(),
 * and that the clock line is configured for multiplexer operations.
 *
 * Params:
 * uint16_t selectLine: the expected value is between 0 and 4
 */
void
/*
 * Called by:
 *  TaskFunction_HallSensors()
 * Calls:
 *  GPIO_setOutputHighOnPin()
 *  GPIO_setOutputLowOnPin()
 *  GPIO_toggleOutputOnPin()
 *  StartMultiplexer()
 *  StopMultiplexer()
 *  Clock_Delay1us()
 * Blocks: none
 * Input: int
 * Bytes used on the stack: 10
 * Returns: none
 */
ToggleMultiplexerSelect(int multiplexer_selectline) {
	int i;
	bool is_falling_edge = true;
	bool multiplexer_started = false;
	bool enable_sent = false, b2_sent = false, b1_sent = false, b0_sent = false;
	GPIO_setOutputLowOnPin(CLOCK_LINE_PORT, CLOCK_LINE_PIN); //set clock line to low

	//iterate 40 times; pseudo clock signal generation that also allows for time after sending data line information
	for (i = 0; i < 40; i++) {

		//toggle chip select pins at the rising edge of the clock
		if (!multiplexer_started) {
			multiplexer_started = true;
			StartMultiplexer();
		}
		GPIO_toggleOutputOnPin(CLOCK_LINE_PORT, CLOCK_LINE_PIN); //alternates clock line
		is_falling_edge = !is_falling_edge;

		//perform data transfers on falling edge of clock signal, as indicated on the multiplexer datasheet
		if (is_falling_edge) {

			//send enable bit
			if (!enable_sent) {
				GPIO_setOutputHighOnPin(MULTIPLEXER_DATA_PORT,
						MULTIPLEXER_DATA_PIN);
				enable_sent = true;
			}

			//send B2 bit
			else if (!b2_sent) {
				if ((multiplexer_selectline >> 2) & 0x01) {
					GPIO_setOutputHighOnPin(MULTIPLEXER_DATA_PORT,
							MULTIPLEXER_DATA_PIN);
				} else {
					GPIO_setOutputLowOnPin(MULTIPLEXER_DATA_PORT,
							MULTIPLEXER_DATA_PIN);
				}
				b2_sent = true;
			}

			//send B1 bit
			else if (!b1_sent) {
				if ((multiplexer_selectline >> 1) & 0x01) {
					GPIO_setOutputHighOnPin(MULTIPLEXER_DATA_PORT,
							MULTIPLEXER_DATA_PIN);
				} else {
					GPIO_setOutputLowOnPin(MULTIPLEXER_DATA_PORT,
							MULTIPLEXER_DATA_PIN);
				}
				b1_sent = true;
			}

			//send B0 bit
			else if (!b0_sent) {
				if ((multiplexer_selectline >> 0) & 0x01) {
					GPIO_setOutputHighOnPin(MULTIPLEXER_DATA_PORT,
							MULTIPLEXER_DATA_PIN);
				} else {
					GPIO_setOutputLowOnPin(MULTIPLEXER_DATA_PORT,
							MULTIPLEXER_DATA_PIN);
				}
				b0_sent = true;
			}

			//if all bits sent, disable chip select lines
			else if (enable_sent && b2_sent && b1_sent && b0_sent) {
				StopMultiplexer();
				GPIO_setOutputLowOnPin(MULTIPLEXER_DATA_PORT,
						MULTIPLEXER_DATA_PIN);
			}

		}

		//Clock line delay. The multiplexers can have a max frequency of 5MHz, so the delay was chosen to be
		//large enough that it could read it so.
		Clock_Delay1us(100);
	}
}
/*
 * Reads the multiplexer output and saves the value for the selected sensor slot.
 * Achieves this using the ADC reading based on the channel parameter.
 *
 * Assumes ToggleMultiplexerSelect has been called before with valid parameters.
 *
 * Params:
 * HallSensorType *HallSensor: the pointer of the struct passed; the "Letters" array
 * of the struct will be changed based on the ADC reading.
 *
 * Return:
 * ADC reading of (*HallSensor) at its memory index, defined in "Defines.h"
 */
uint32_t
/*
 * Called by:
 *  TaskFunction_HallSensors()
 * Calls:
 *  ADC14_getResult()
 * Blocks: none
 * Input: HallSensorType*
 * Bytes used on the stack: 4
 * Returns: uint32_t
 */
ReadMultiplexerOutput(HallSensorType *HallSensor) {

	uint16_t result;
	//ADC reading for the sensor
	result = ADC14_getResult(HallSensor->ADCMemoryIndex);

	return result;
}

/*
 * Set all of the CS Lines of the multiplexers to LOW
 */
void
/*
 * Called by:
 *  TaskFunction_HallSensors()
 * Calls:
 *  GPIO_setOutputLowOnPin()
 * Blocks: none
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
StopMultiplexer() {
	//set all cs lines low
	int i;
	for (i = 0; i < NUMBER_OF_CHANNELS; i++) {
		GPIO_setOutputLowOnPin(multiplexer_cs_ports[i], multiplexer_cs_pins[i]);
	}
}

/*
 * Initalize the ADC for hall sensors.
 *
 * ADC Parameters to change:
 * Clock Source: SMCLK
 * Clock Source Divider: ADC_PREDIVIDER_1 (indicates no clock divider)
 * Clock Predivider Divider: ADC_DIVIDER_1 (indicates no dividing on the clock predivided frequency)
 * Internal Channel Mask: ADC_NOROUTE (indicates no changes to pin mapping of ADC pins)
 * Reference voltage: ADC_VREFPOS_AVCC_VREFNEG_VSS (indicates positive VCC, negative/ground VSS)
 * Differential mode: ADC_NONDIFFERENTIAL_INPUTS (indicates not using difference between channels)
 * Sample Hold Time: ADC_PULSE_WIDTH_32 for first and second pulse widths (indicates longer waiting
 *  for ADC to take samples)
 * Conversion enable: ADC_MANUAL_ITERATION (indicates manual toggling of enabling ADC conversion)
 *
 * Modes:
 * Multiple sample mode: on (indicates ADC will take multiple samples and store in contiguous memory location)
 * Repeat sample mode: off (indicates ADC will only take one set of samples per method call)
 *
 * Allocated Memory Indexes:
 * ADC_MEM2
 * ADC_MEM3
 * ADC_MEM4
 * ADC_MEM5
 * ADC_MEM6
 *
 * Channel Indexes:
 * ADC_INPUT_A14 - index at GPIO P6.1
 * ADC_INPUT_A13 - index at GPIO P4.0
 * ADC_INPUT_A11 - index at GPIO P4.2
 * ADC_INPUT_A9 - index at GPIO P4.4
 * ADC_INPUT_A8 - index at GPIO P4.5
 *
 * Enabling Conversion:
 * ADC14_enableModule(); enables ADC block
 * ADC14_enableConversion(); enable conversion (does not actually tell ADC to perform conversion)
 * ADC14_toggleConversion(); toggles trigger software bit, starts conversion
 *
 * HallSensor memory indexes are in "Defines.h"
 */
void
/*
 * Called by: main()
 * Calls:
 *  InitializeHallSensors()
 *  ADC14_initModule()
 *  ADC14_configureConversionMemory()
 *  ADC14_configureMultiSequenceMode()
 *  ADC14_setSampleHoldTime()
 *  ADC14_enableSampleTimer()
 *  ADC14_enableModule()
 *  ADC14_enableConversion()
 *  ADC14_toggleConversionTrigger()
 *  UART0_OutString() *for debugging*
 * Blocks: None
 * Bytes used on the stack: 4
 * Returns: none
 */
InitializeADC_HallSensors(void) {
	uint32_t i;
	InitializeHallSensors();
	ADC14_initModule(ADC_CLOCKSOURCE_SMCLK,
	ADC_PREDIVIDER_1,
	ADC_DIVIDER_1,
	ADC_NOROUTE);
	for (i = 0; i < NUMBER_OF_HALL_SENSORS; i++) {
		ADC14_configureConversionMemory(HallSensors[i].ADCMemoryIndex,
		ADC_VREFPOS_AVCC_VREFNEG_VSS, HallSensors[i].AnalogChannel,
		ADC_NONDIFFERENTIAL_INPUTS);
	}
	ADC14_configureMultiSequenceMode(ADC_MEM2, ADC_MEM6, false);
	ADC14_setSampleHoldTime(ADC_PULSE_WIDTH_32, ADC_PULSE_WIDTH_32);
	ADC14_enableSampleTimer(ADC_MANUAL_ITERATION);
	//another multiple sample conversion setting in case configureMultiSequenceMode()
	//does not go through
	ADC14->CTL0 |= ADC14_CTL0_MSC;
	ADC14_enableModule();
	ADC14_enableConversion();
	ADC14_toggleConversionTrigger();

	UART0_OutString("ADC: Initialized \r\n");
}

/*
 * Initialize the GPIO pins for the multiplexer.
 *
 * Multiplexer CS: chip select pin. High toggles reading, low toggles multiplexer output.
 *  GPIO P4.3
 * Multiplexer Data: line select pin. Inputs while CS is high toggles the reading line.
 *  GPIO P4.6
 *
 * Sets both of the output pins to LOW.
 */
void
/*
 * Called by: main()
 * Calls:
 *  GPIO_setAsOutputPin()
 *  GPIO_setOutputLowOnPin()
 *  UART0_OutString() *for debugging*
 * Blocks: none
 * Bytes used on the stack: 4
 * Returns: none
 */
InitializeMultiplexerPins() {

	//set GPIO pins as output
	//set output of select pins to low
	int i;
	for (i = 0; i < NUMBER_OF_CHANNELS; i++) {
		GPIO_setAsOutputPin(multiplexer_cs_ports[i], multiplexer_cs_pins[i]);
		GPIO_setOutputLowOnPin(multiplexer_cs_ports[i], multiplexer_cs_pins[i]);
	}

	//set multiplexer data line
	GPIO_setAsOutputPin(MULTIPLEXER_DATA_PORT, MULTIPLEXER_DATA_PIN);
	GPIO_setOutputLowOnPin(MULTIPLEXER_DATA_PORT, MULTIPLEXER_DATA_PIN);

	//configure clock line
	GPIO_setAsOutputPin(CLOCK_LINE_PORT, CLOCK_LINE_PIN);

	UART0_OutString("Multiplexer: Initialied \r\n");
}

/*
 * Initialize the hall sensor pins
 *
 * Calls InitializeHallSensor() on each of the sensors in the HallSensors[] array.
 *  Sets their respective ADC channels, indexes, and IDs (defined in "Defines.h")
 *
 * Sets each port and pin to a peripheral module function input pin with primary module functionality:
 * GPIO P6.1
 * GPIO P4.0
 * GPIO P4.2
 * GPIO P4.4
 * GPIO P4.5
 *
 * Set P6SEL0/1 and P9SEL0/1 to 1; enables ADC mode
 *
 * NOTE: initialization of letter slots 3 and 5 were swapped due to the implementation of our ports. This
 * was project specific and an oversight on our part.
 */
void
/*
 * Called by: main()
 * Calls:
 *  ADC14_isBusy()
 *  InitializeHallSensor()
 *  GPIO_setAsPeripheralModuleFunctionInputPin()
 *  UART0_OutString() *for debugging*
 * Blocks: waits for the ADC to finish conversion using ADC14_isBusy()
 * Bytes used on the stack: 0
 * Returns: none
 */
InitializeHallSensors() {
	while (ADC14_isBusy()) {
	}; //wait for ADC to finish conversion

	//initialize hall sensors
	InitializeHallSensor(&HallSensors[0],
	LETTER_SENSOR_1_CHANNEL,
	LETTER_SENSOR_1_INDEX, 0);
	InitializeHallSensor(&HallSensors[1],
	LETTER_SENSOR_2_CHANNEL,
	LETTER_SENSOR_2_INDEX, 1);
	InitializeHallSensor(&HallSensors[4],
	LETTER_SENSOR_3_CHANNEL,
	LETTER_SENSOR_3_INDEX, 4);
	InitializeHallSensor(&HallSensors[3],
	LETTER_SENSOR_4_CHANNEL,
	LETTER_SENSOR_4_INDEX, 3);
	InitializeHallSensor(&HallSensors[2],
	LETTER_SENSOR_5_CHANNEL,
	LETTER_SENSOR_5_INDEX, 2);

	//set each letter slots for ADC conversion
	GPIO_setAsPeripheralModuleFunctionInputPin(LETTER_SENSOR_1_PORT,
	LETTER_SENSOR_1_PIN,
	GPIO_PRIMARY_MODULE_FUNCTION);
	GPIO_setAsPeripheralModuleFunctionInputPin(LETTER_SENSOR_2_PORT,
	LETTER_SENSOR_2_PIN,
	GPIO_PRIMARY_MODULE_FUNCTION);
	GPIO_setAsPeripheralModuleFunctionInputPin(LETTER_SENSOR_3_PORT,
	LETTER_SENSOR_3_PIN,
	GPIO_PRIMARY_MODULE_FUNCTION);
	GPIO_setAsPeripheralModuleFunctionInputPin(LETTER_SENSOR_4_PORT,
	LETTER_SENSOR_4_PIN,
	GPIO_PRIMARY_MODULE_FUNCTION);
	GPIO_setAsPeripheralModuleFunctionInputPin(LETTER_SENSOR_5_PORT,
	LETTER_SENSOR_5_PIN,
	GPIO_PRIMARY_MODULE_FUNCTION);

	//toggle select bits for ADC operation
	P6SEL1 = 0x01;
	P6SEL0 = 0x01;
	P4SEL1 = 0x01;
	P4SEL0 = 0x01;

	UART0_OutString("HallSensors: Initialized \r\n"); //debug
}

/*
 * Initializes the LCD as well as the display settings.
 *
 * Sets the the LCD clock, chip select, MOSI, and MISO lines for SPI communcication.
 * Calls TFT_init() afterwards to initialize beginning display state. Clock speed
 * is 1MHz to meet LCD requirement that initialization is less than 11MHz at
 * initiation. This is specified in the LCD's datasheet.
 *
 * Sets the clock line to 12MHz afterwards to increase speed.
 */
void
/*
 * Called by: main()
 * Calls:
 *  EVE_SPI_Init()
 *  Clock_Delay1ms()
 *  EVE_init()
 *  TFT_init()
 *  EVE_SPI_Init_High_Frequency()
 * Blocks:
 *  if EVE_init() does not return 1, this method is blocked.
 *      This is dependent on the MSP receiving the chip identification code from the LCD
 *      as well as the LCD allowing for commands to be sent into its command buffer.
 *  TFT_init() is blocking if the data sent in the commands its methods call do not get processed
 *  properly.
 * Bytes used on the stack: 0
 * Returns: none
 */
InitializeLCDPins() {

	EVE_SPI_Init(); //initialize SPI
	Clock_Delay1ms(20); //delay
	//initialize the display
	if (EVE_init() != 0) {
		TFT_init(); //initialize display on startup
	}
	EVE_SPI_Init_High_Frequency(); //initialize SPI with higher frequency
}

/*
 * EUSCI A0 UART ISR - Echoes data back to PC host
 *
 * This method is toggled whenever the MSP receives data from PC client. This is an IRQ
 * handler, so it activates asynchronously.
 *
 * Reads the data sent from the PC client and updates the circular buffer. Processes the
 * data read afterwards.
 *
 * Uses UART with EUSCIA0 base for backchannel UART communication.
 */
void
/*
 * Called by: EUSCIA0 Interrupt (this is asynchronous from the other threads)
 * Calls:
 *  UART_getEnabledInterruptStatus()
 *  UART_clearInterruptFlag()
 *  processItem()
 *
 * Blocks:
 *  This method is blocking if the interrupt flag is not cleared fast enough.
 * Bytes used on the stack: 4
 * Returns: none
 */
EUSCIA0_IRQHandler(void) {

	b_updating_images = true;

	euscia0_count++; //debug var

	//check if interrupt was for EUSCI_A0
	uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A0_BASE);

	//if interrupt was for EUSCI_A0, update circular buffer and process it
	if (status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) {
		base = UART_receiveData(EUSCI_A0_BASE);
		processItem(base);
	}

	//clear UART interrupt flag
	UART_clearInterruptFlag(EUSCI_A0_BASE, status);
}
