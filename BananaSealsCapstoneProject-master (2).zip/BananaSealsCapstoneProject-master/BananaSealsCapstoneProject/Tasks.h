/*
 * Task.h
 *
 *  Created on: Feb 23, 2021
 *      Author: justi
 */

#ifndef TASKS_H_
#define TASKS_H_
#include "FSM.h"


// Type Definitions

typedef struct{
    void (*Task)(FSMType *);
    uint32_t TaskCycleCounter;
    uint32_t TaskExecutionPeriod;
    FSMType *FSM;
} TaskType;

//Function Prototypes
void TaskSchedulerISR(void);


#endif /* TASKS_H_ */
