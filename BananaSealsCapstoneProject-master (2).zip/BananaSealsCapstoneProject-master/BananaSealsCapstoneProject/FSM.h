/*
 * FSM.h
 *
 *  Created on: Feb 23, 2021
 *      Author: justin
 */

#ifndef FSM_H_
#define FSM_H_
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "Defines.h"

// Type Definitions

typedef struct {
    uint32_t value;
    char* CurrentString;
    char* CorrectString;
} FSMType;

typedef struct{
    FSMType FSM;
    uint32_t AnalogChannel;
    uint32_t ADCMemoryIndex;
    uint16_t Reading[NUMBER_OF_CHANNELS];
    uint32_t CumulativeSum;
    uint32_t SensorAverage;
    uint32_t BufferIndex;
    uint32_t LetterIndex;
    uint32_t SensorInputBuffer[SENSOR_INPUT_BUFFER_LENGTH];
    bool CycleComplete;
    char CurrentLetter;
} HallSensorType;

//old Function Prototypes
void InitializeFSM(FSMType *FSM, uint32_t value);

//end replacement
void NextStateFunction(FSMType *FSM);
void OutputFunction(FSMType *FSM);

//new
void InitializeHallSensor(HallSensorType *HallSensor, uint32_t AnalogChannel, uint32_t ADCMemoryIndex, uint32_t SensorID);
uint32_t ConvertHallSensorReading(uint32_t SensorInput);
#endif /* FSM_H_ */
