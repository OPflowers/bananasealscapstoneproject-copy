/*
 * Tasks.c
 *
 *  Created on: Feb 23, 2021
 *      Author: justi
 */

#include "Tasks.h"
#include "UART0.h"
#include "FSM.h"
#include "Defines.h"
extern TaskType Tasks[NUMBER_OF_TASKS]; //global variable to track tasks

/*
 * Task Scheduler Implementation
 *
 * Loops through the number of tasks and updates their CycleCounters.
 * If the CycleCounter equals its ExecutionPeriod, the task scheduler
 *  resets the CycleCounter and executes the function passed to the Task.
 */
void
/*
 * Called by:
 *  TA1_0_IRQHandler()
 * Calls:
 *  Methods inside the Tasks array
 * Blocks:
 *  Dependent on the methods executed
 * Input: none
 * Bytes used on the stack: 4
 * Returns: none
 */
TaskSchedulerISR(void){
    int i;
    for (i = 0; i < NUMBER_OF_TASKS; i++){
        //uint32_t counter = Tasks[i].TaskCycleCounter;
        if(Tasks[i].TaskCycleCounter >= Tasks[i].TaskExecutionPeriod){
            Tasks[i].TaskCycleCounter = 0;
            (*Tasks[i].Task)((FSMType *)Tasks[i].FSM);
        }
        else Tasks[i].TaskCycleCounter++;
    }
}


