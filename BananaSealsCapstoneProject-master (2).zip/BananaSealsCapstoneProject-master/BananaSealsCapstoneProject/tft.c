/*
 * tft.c
 *
 *  Created on: Nov 19, 2021
 *      Author: Justin Guo
 */

/* DriverLib Include */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Library Includes */
#include "Clock.h"
#include "tft.h"
#include "tft_data.h"
#include "EVE.h"
#include "Defines.h"

#define SECTOR_0_ADDR 0x00020000 //sector 0 of bank 1
#define MEM_LOGO 0x000f8000 /* start-address of logo, needs 6272 bytes of memory, mainly for debugging */
#define MEM_PIC1 0x00000000 /* start of 100x100 pixel test image, ARGB565, needs 20000 bytes of memory */
#define LAYOUT_Y1 66 //layout for debugging

extern const int sector_array[NUM_SECTORS]; //get sectors from main.c
extern image_properties_t dictionary[NUM_IMAGES]; //get dictionary from main.c

char *p_input_word; //pointer that represents inputted word
char *p_correct_word = "beans"; //pointer that represents correct word
int g_TFT_game_state = 0; //global variable, represents state of the game
uint8_t g_font_widths[NUM_ASCII_FONTS]; //global array, stores the font widths of the current font used

uint8_t g_current_image_index = 0; //global variable, represents current image selected
uint8_t g_num_of_images; //global variablem represents total number of images in the system

//check for if the image was changed. This occurs when the user inputs correct word and hits the touch
//button again.
bool b_image_changed = false;

//check for if all the images were flashed from the last UART transmission session.
bool b_flash_images_finished = true;

/*
 * Sets the LCD display up for initial display settings.
 *
 * Gets the existing images that were previous flashed into the MSP and adds them to the dictionary.
 * Initializes touch and starts a recalibration process for the LCD.
 * Reads the font widths for the current font from the LCD and adds them to the g_font_widths array
 * Starts the first display.
 */
void
/*
 * Called by: InitializeLCDPins() in main.c
 * Calls:
 *  TFT_get_existing_images()
 *  TFT_touch_init()
 *  TFT_recalibrate()
 *  TFT_get_font_widths()
 *  TFT_display()
 *  Clock_Delay1ms()
 * Blocks:
 *  TFT_get_existing_images() is blocking if the LCD does not send back data properly. This can
 *      happen with bad cables or wires.
 *  TFT_recalibrate() is blocking as long as the LCD does not receive touch signals.
 *  TFT_display() is blocking if the LCD does not receive proper data.
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_init() {

	//get last image list flashed
	TFT_get_existing_images();

	//set touch parameters
	TFT_touch_init();

	//recalibrate touch with touch inputs
	TFT_recalibrate();

	//small delay to allow for LCD to update touch inputs
	Clock_Delay1ms(50);

	//write to LCD to get font widths
	TFT_get_font_widths(FONT);

	//display first display list on LCD
	TFT_display();
}

/*
 * Gets the font widths from the LCD for the currently used font.
 *
 * The address of the font root is stored in EVE_ROM_FONT_ADDR, which is 0x002FFFFC according to the LCD's
 * programmer's guide. Each font has a 148 byte descriptor, which begins indexing at font 16. Fonts 16-32
 * can be read beginning at p_font_root + (148 * (font - 16)) and indexed at 1 afterwards.
 *
 * Adds the font widths read into the g_font_widths array.
 *
 * This method is technically blocking if communication with the LCD prevents reading memory addresses.
 *
 * Params: takes in a font as an int. This value is assumed to be between 16 and 32.
 */
void
/*
 * Called by: TFT_init()
 * Calls:
 *  EVE_memRead32()
 *  EVE_memRead8()
 * Blocks:
 *  EVE_memRead32() and EVE_memRead8() are both blocking if communication with the LCD is
 *  disrupted.
 * Input: int
 * Bytes used on the stack: 12
 * Returns: none
 */
TFT_get_font_widths(int font) {
	//get font root address
	uint32_t p_font_root = EVE_memRead32(EVE_ROM_FONT_ADDR);

	//get font descriptor starting address for the inputted font
	uint32_t p_font_widths = p_font_root + (148 * (font - 16)); //programmers guide

	//iterate through the font descriptor, add to font widths array
	int i;
	for (i = 0; i < NUM_ASCII_FONTS; i++) {
		uint32_t read_byte = p_font_widths + i;
		g_font_widths[i] = EVE_memRead8(read_byte);
	}

}

/*
 * Checks to see if there are any images in flash, and if there are, adds them to the
 * dictionary. If there are images in flash, loads the first image into the LCD's RAM
 * to be displayed next. If there are no images in flash, loads the default image of
 * a picture of beans to the display and sets that image as the dictionary's only image.
 */
void
/*
 * Called by: TFT_init()
 * Calls:
 *  FlashCtl_verifyMemory()
 *  TFT_load_image_with_array()
 *  TFT_load_image();
 * Blocks:
 *  TFT_load_image_with_array() and TFT_load_image() are blocking if communcation with the LCD is disrupted.
 *  FlashCTL_verifyMemory() is blocking by default.
 * Input: none
 * Bytes used on the stack: up to 8012 bytes.
 * Returns: none
 */
TFT_get_existing_images() {

	int index = 0;
	//calculate flash address of first image, which must be in Bank 1, sector 0 of the MSP's flash
	uint32_t flash_addr = (0x1000 * 2 * (index) + (0x20000));

	//while an image exists in the current sector, add that to the dictionary.
	//this is done by reading the first 30 bytes of the sector address and
	//checking to see if the pattern is all 0xFF (no image) or not (image)
	while (!FlashCtl_verifyMemory((void*) flash_addr, 30, FLASH_1_PATTERN)) {
		dictionary[index] = TFT_get_image_params(index); //get image parameters from flash
		flash_addr += IMAGE_STORAGE_SIZE; //update the flashing address
		index++;
	}

	//if at least one image exists
	if (index != 0) {
		g_num_of_images = index;
		g_current_image_index = 0;

		//set the first image's word to be the correct word
		p_correct_word = dictionary[0].image_word;

		//image buffer to read from flash
		uint8_t image_buffer[8000];
		uint32_t flash_image_addr = (0x20000) + IMAGE_PARAM_BYTES;
		int i;
		for (i = 0; i < dictionary[g_current_image_index].image_size; i++) {
			image_buffer[i] = *(uint8_t*) (flash_image_addr + i);
		}

		//load the first image into the LCD's RAM
		TFT_load_image_with_array(image_buffer,
				dictionary[g_current_image_index].image_size);

	}

	//if no images were in flash
	else {
		//load default image
		TFT_load_image();

		//create new image properties struct with parameters. These are hard coded because the default
		//image is also hardcoded and contains specific properties anyways.
		image_properties_t tempImageProps;
		tempImageProps.height = 78;
		tempImageProps.width = 72;
		tempImageProps.image_size = 3205;
		strcpy(tempImageProps.image_type, "jpeg");
		strcpy(tempImageProps.image_word, "beans");
		tempImageProps.image = (void*) pic;
		dictionary[0] = tempImageProps; //add to newly created struct to dictionary

		g_current_image_index = 0;
	}
}

/*
 * Clears the current image inside the LCD's RAM.
 * Achieves this by writing over its RAM with zeros.
 */
void
/*
 * Called by: TFT_display()
 * Calls:
 *  EVE_cmd_memzero()
 * Blocks:
 *  EVE_cmd_memzero() is blocking if communication with the LCD is disrupted.
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_clear_image(int size) {
	EVE_cmd_memzero(MEM_PIC1, size);
}

/*
 * Toggles b_flash_images_finished variable, signaling that the flashing
 * process is complete.
 */
void
/*
 * Called by: processItem() in main.c
 * Calls: none
 * Blocks: none
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_flash_finished() {
	b_flash_images_finished = true;
}

/*
 * Flashes an image into the MSP's memory. This includes the image properties as well.
 * Flashing the image follows this order:
 *  1. height
 *  2. width
 *  3. image size
 *  4. file type
 *  5. word
 *  6. image data
 *
 * Param: int sector_index is assumed to be between 0 and 15, as the max number of images
 * flashable is 16
 */
void
/*
 * Called by: processItem() in main.c
 * Calls:
 *  FlashCtl_verifyMemory()
 *  FlashCtl_unprotectSector()
 *  FlashCtl_performMassErase()
 *  FlashCtl_protectSector()
 *  FlashCtl_programMemory()
 * Blocks:
 *  ALL FlashCtl methods called are blocking by default.
 * Input:
 *  uint16_t height
 *  uint16_t width
 *  uint32_t image_size
 *  char image_type[5]
 *  char word[6]
 *  uint8_t image_array[]
 *  int sector_index
 * Bytes used on the stack: 16
 * Returns: none
 */
TFT_flash_image(uint16_t height, uint16_t width, uint32_t image_size,
		char image_type[5], char word[6], uint8_t image_array[],
		int sector_index) {

	//if images done flashing, set number of images to 0 and toggle b_flash_images_finished
	if (b_flash_images_finished == true) {
		g_num_of_images = 0;
		b_flash_images_finished = false;
	}

	//toggle image changed; changes state later
	b_image_changed = true;

	g_current_image_index = 0;

	uint32_t flash_addr = (0x1000 * 2 * (sector_index) + (0x20000));
	uint32_t flash_addr_start = (0x1000 * 2 * (sector_index) + (0x20000));

	//verify first 30 bytes and check if there already exists data
	if (!FlashCtl_verifyMemory((void*) flash_addr_start, 30, FLASH_1_PATTERN)) {

		//if data already exists in the current sector, erase sector before writing to sector again
		FlashCtl_unprotectSector(FLASH_MAIN_MEMORY_SPACE_BANK1,
				sector_array[2 * sector_index]
						| sector_array[2 * sector_index + 1]);
		FlashCtl_performMassErase(); //erase memory if sector already contains info
		FlashCtl_protectSector(FLASH_MAIN_MEMORY_SPACE_BANK1,
				sector_array[2 * sector_index]
						| sector_array[2 * sector_index + 1]);
	}

	//open flash sector
	FlashCtl_unprotectSector(FLASH_MAIN_MEMORY_SPACE_BANK1,
			sector_array[2 * sector_index]
					| sector_array[2 * sector_index + 1]);

	//flash height
	uint8_t height_buffer[] = { height & 0xFF, (height >> 8) & 0xFF };
	FlashCtl_programMemory((void*) height_buffer, (void*) flash_addr_start,
			sizeof(height));
	flash_addr_start += sizeof(height);

	//flash width
	uint8_t width_buffer[] = { width & 0xFF, (width >> 8) & 0xFF };
	FlashCtl_programMemory((void*) width_buffer, (void*) flash_addr_start,
			sizeof(width));
	flash_addr_start += sizeof(width);

	//flash image size
	uint8_t image_size_buffer[] = { image_size & 0xFF, (image_size >> 8) & 0xFF,
			(image_size >> 16) & 0xFF, (image_size >> 24) & 0xFF };
	FlashCtl_programMemory((void*) image_size_buffer, (void*) flash_addr_start,
			sizeof(image_size));
	flash_addr_start += sizeof(image_size);

	//flash image_type
	FlashCtl_programMemory((void*) image_type, (void*) flash_addr_start,
			sizeof(image_type));
	flash_addr_start += IMAGE_TYPE_SIZE; //accounts for any null pointers

	//flash word
	FlashCtl_programMemory((void*) word, (void*) flash_addr_start,
	IMAGE_WORD_SIZE);
	flash_addr_start += IMAGE_WORD_SIZE;

	//flash image
	FlashCtl_programMemory(image_array,
			(void*) (flash_addr + IMAGE_PARAM_BYTES), image_size);

	//close sector
	FlashCtl_protectSector(FLASH_MAIN_MEMORY_SPACE_BANK1,
			sector_array[2 * sector_index]
					| sector_array[2 * sector_index + 1]);

	p_correct_word = dictionary[0].image_word; //set the correct word to be the first image's word

	g_num_of_images++; //update number of images
}

/*
 * Gets the image parameters given an image index. Reads from flash memory the address
 * corresponding to the inputted image index and returns image parameters.
 *
 * The 19 bytes this method reads are allocated in order as follows:
 *  1. height: first 2 bytes
 *  2. width: next 2 bytes
 *  3. image size: next 4 bytes
 *  4. file type: next 5 bytes
 *  5. word: next 6 bytes
 *
 * Due to how TFT_flash_image() is implemented, the parameters are always stored at the
 * beginning of the flash sector in memory.
 */
image_properties_t
/*
 * Called by: TFT_get_existing_images()
 * Calls:
 *  sizeof()
 * Blocks: none
 * Input: int
 * Bytes used on the stack: 27
 * Returns: image_properties_t
 */
TFT_get_image_params(int index) {
	image_properties_t temp_image;
	uint32_t flash_addr = (0x1000 * 2 * (index) + (0x20000));

	//get height
	temp_image.height = (uint16_t) (*(uint8_t*) (flash_addr))
			+ (uint16_t) (*(uint8_t*) (flash_addr + 1) << 8);
	flash_addr += sizeof(temp_image.height);

	//get width
	temp_image.width = (uint16_t) (*(uint8_t*) (flash_addr))
			+ (uint16_t) (*(uint8_t*) (flash_addr + 1) << 8);
	flash_addr += sizeof(temp_image.width);

	//get image_size
	temp_image.image_size = (uint16_t) (*(uint8_t*) (flash_addr))
			+ (uint16_t) (*(uint8_t*) (flash_addr + 1) << 8)
			+ (uint16_t) (*(uint8_t*) (flash_addr + 2) << 16)
			+ (uint16_t) (*(uint8_t*) (flash_addr + 3) << 24);
	flash_addr += sizeof(temp_image.image_size);

	//get image_type
	int i;
	for (i = 0;
			i < sizeof(temp_image.image_type) / sizeof(temp_image.image_type[0]);
			i++) {
		uint8_t temp_character = *(uint8_t*) (flash_addr + i);
		//only flash characters that are not 0xFF. A character could be read as 0xFF here
		//due to the null terminator occuring early in the string.
		if (temp_character != 0xFF) {
			temp_image.image_type[i] = temp_character;
		}
	}
	flash_addr += IMAGE_TYPE_SIZE;

	//get word
	for (i = 0;
			i < sizeof(temp_image.image_word) / sizeof(temp_image.image_word[0]);
			i++) {
		uint8_t temp_character = *(uint8_t*) (flash_addr + i);
		//only flash characters that are not 0xFF. A character could be read as 0xFF here
		//due to the null terminator occuring early in the string.
		if (temp_character != 0xFF) {
			temp_image.image_word[i] = temp_character;
		}

	}
	return temp_image;
}

/*
 * Sets the variable g_TFT_game_state to be TFT_DEFAULT, indicating that the
 * LCD displays a picture without highlighting
 */
void
/*
 * Called by: main() in main.c
 * Calls: none
 * Blocks:none
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_set_display_default() {
	g_TFT_game_state = TFT_DEFAULT;
}

/*
 * Sets p_input_word to the current input string. Note that these two
 * are both pointers, so they will always point to the same value after this call.
 */
void
/*
 * Called by: TaskFunction_LCD() in main.c
 * Calls: none
 * Blocks:none
 * Input: char*
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_update_words(char *p_current_input_string) {
	p_input_word = p_current_input_string;
}

/***
 * This method was partly adapted from GitHub user RudolphRiedel's FT800-FT813 Library.
 *
 * Changes the toggle state of the LCD based on touch tags generated by the LCD
 *
 * Returns an int indicating whether to compare the current word with the correct word (1)
 * or to not (0).
 *
 * It should be noted that the button was given a tag value of 10.
 */

uint16_t g_toggle_state = 0;
uint16_t display_list_size = 0;
uint16_t g_toggle_multiplexers = 0;

int
/*
 * Called by: TaskFunction_LCD() in main.c
 * Calls:
 *  EVE_busy()
 *  EVE_memRead8()
 *  Eve_memRead16()
 * Blocks:
 *  ALL EVE functions are blocking if communication with the LCD is disrupted
 *  EVE_busy() in particular is blocking if the LCD command space is never refreshed.
 * Input: none
 * Bytes used on the stack: 5
 * Returns: int
 *  0: do not check word
 *  1: do check word
 */
TFT_touch() {
	uint8_t tag;
	int return_val = 0;

	//if LCD is still processing, just return
	if (EVE_busy()) {
		return return_val;
	}

	tag = EVE_memRead8(REG_TOUCH_TAG); //read value for touch point

	display_list_size = EVE_memRead16(REG_CMD_DL); //debug info

	//return 1 and compare words on button release

	//if tag is 0
	if (tag == 0) {
		g_toggle_state = 0;
		//if g_toggle_multiplexers == 1, this indicates that the button was already pressed
		if (g_toggle_multiplexers == 1) {
			return_val = 1;
			g_toggle_multiplexers = 0;
		}
	}
	//if tag is 10
	else if (tag == 10) {
		//signal that button was pressed down
		g_toggle_state = EVE_OPT_FLAT; //display option to make button look flattened
		g_toggle_multiplexers = 1;
	}
	return return_val;

}
/*
 * Loads the default image inside tft_data.c into the LCD's RAM
 *
 * Also flashes the default into the MSP's memory starting at Bank1, sector 0.
 */
void
/*
 * Called by: TFT_get_existing_images()
 * Calls:
 *  FlashCtl_unprotectSector()
 *  FlashCtl_eraseSector()
 *  FlashCtl_programMemory()
 *  FlashCtl_protectSector()
 * Blocks:
 *  ALL FlashCtl methods are blocking by default.
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_load_image() {

	//open sectors 0 and 1 in bank 1
	FlashCtl_unprotectSector(FLASH_MAIN_MEMORY_SPACE_BANK1,
	FLASH_SECTOR0 |
	FLASH_SECTOR1);

	//erase both sectors before flashing, in case previous data still existed
	if (!FlashCtl_eraseSector(SECTOR_0_ADDR)) {
		printf("erase sector B failed");
	}
	if (!FlashCtl_eraseSector(SECTOR_0_ADDR + 0x1000)) {
		printf("erase sector C failed");
	}

	Clock_Delay1ms(20);

	//flash default picture to memory
	if (!FlashCtl_programMemory((void*) pic,
			(void*) (0x20000 + IMAGE_PARAM_BYTES), sizeof(pic))) {
		printf("program memory failed");
	}
	Clock_Delay1ms(20);

	//close opened sectors
	FlashCtl_protectSector(FLASH_MAIN_MEMORY_SPACE_BANK1,
	FLASH_SECTOR0 |
	FLASH_SECTOR1);

	EVE_cmd_memzero(MEM_PIC1, 8192); //clear picture RAM in LCD
	EVE_cmd_loadimage(MEM_PIC1, EVE_OPT_NODL, pic, sizeof(pic)); //load default picture in LCD RAM
	g_num_of_images = 1; //update number of images
}

/*
 * Loads an image into the LCD's RAM given a size and a data array.
 *
 * Params: size should be the size of the image_array given, and size should
 * not be larger than 8KB.
 */
void
/*
 * Called by:
 *  TFT_get_existing_images()
 *  TFT_display()
 * Calls: EVE_cmd_loadimage()
 * Blocks: EVE_cmd_loadimage() is blocking if communication with the LCD is disrupted
 * Input:
 *  uint8_t image_array[]
 *  int size
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_load_image_with_array(uint8_t image_array[], int size) {
	EVE_cmd_loadimage(MEM_PIC1, EVE_OPT_NODL, image_array, size); //load image
}

/*
 * Compares the current input word and the correct word,
 * and updates the display state based in the result.
 *
 * If the inputted word was already previously checked to be correct, then
 * cycle to the next image and change the word.
 *
 * Otherwise, changes the display state to TFT_DISPLAY_WRONG if
 * the words are not the same and to TFT_DISPLAY_RIGHT if they are.
 *
 */
void
/*
 * Called by: TaskFunction_LCD() in main.c
 * Calls:
 *  strlen()
 *  toupper()
 * Blocks:none
 * Input: none
 * Bytes used on the stack: 4
 * Returns: none
 */
TFT_check_words() {
	//case if the game state was already checked to be right
	if (g_TFT_game_state == TFT_DISPLAY_RIGHT) {

		g_current_image_index = g_current_image_index + 1; //next image index
		if (g_current_image_index == g_num_of_images) {
			g_current_image_index = 0; //cycle back if end of index
		}

		p_correct_word = dictionary[g_current_image_index].image_word; //update next word

		b_image_changed = true; //signal that an image changed

		g_TFT_game_state = TFT_DEFAULT; //remove highlighting
	}

	//case where the word lenghts are different; trivial case that words are wrong
	else if (strlen(p_input_word) != strlen(p_correct_word)) {
		g_TFT_game_state = TFT_DISPLAY_WRONG;
	}

	//otherwise, iterate through each letter and compare them to see if they match or not
	else {
		int i;
		for (i = 0; i < strlen(p_input_word); i++) {
			if (toupper(p_input_word[i]) != toupper(p_correct_word[i])) {
				g_TFT_game_state = TFT_DISPLAY_WRONG; //letter doesn't match, change to TFT_DISPLAY_WRONG
				return;
			}
		}
		g_TFT_game_state = TFT_DISPLAY_RIGHT; //all letters match, change to TFT_DISPLAY_RIGHT
	}
}
/*
 * This method was partly adapted from GitHub user RudolphRiedel's FT800-FT813 Library.
 *
 * Controls the next image to be displayed.
 *
 * Contains Four main components:
 *  1. An image
 *  2. A touch button
 *  3. A string of text
 *  4. Highlighting
 *
 * 1. The image
 * This is the image loaded into the LCD's RAM. If the b_image_changed variable is true, then
 * this method also loads in the next image's data into the LCD's RAM. Displays the image by
 * loading it as a bitmap on the LCD. Depending on the image's file type, this method will load
 * it as either an RGB565 for jpeg images or an ARGB4 for other images.
 *
 * 2. The touch button
 * A touch button is drawn onto the upper right hand side of the display. This technically an image
 * with a special tag of value 10. When pressed, the value of the touch register in the LCD will be
 * replaced with its tag value, and the new pressed down look of the button is updated in TFT_touch().
 * It reverts back to its original appearance when released due to TFT_touch()'s implementation.
 *
 * 3. The string of text
 * This is a string of text created based on the current input string and the correct word. The default
 * color is black text.
 *   a. If the the current input string has no letters, then the string of text will be calculated
 *   to be underscores repeated by the number of letters in the correct word and separated by spaces.
 *      Ex:
 *      Current input string: ""
 *      Correct word: "cow"
 *      String of text: "_ _ _ "
 *   b. If the current input string has letters but has less than the correct word, then the string
 *   of text will be left-aligned with the current input letters and filled with underscores, all
 *   separated with spaces.
 *      Ex:
 *      Current input string: " ow"
 *      Correct word: "cow"
 *      String of text: "o w _ "
 *   c. If the current input string has letters and contains the same number of letters as the
 *   correct word, the string of text will be the current input string separated with spaces.
 *      Ex:
 *      Current input string: "cow"
 *      Correct word: "cow"
 *      String of text: "c o w "
 *   d. If the current input string has more letters than the correct word, the string of text will
 *   be the correct word separated with spaces but with red text instead of black.
 *      Ex: Current input string: "acow"
 *      Correct word: "cow"
 *      String of text: "a c o w" (with red text)
 * 4. Highlighting
 * The highlighting is dependent on the string of text created and the current game state. The
 * highlighting uses the font widths and colors rectangles behind the text.
 *  a. If the game state is TFT_DISPLAY_WRONG, highlights the incorrect letters in the string of text.
 *  This includes underscores. The color for WRONG highlighting is red.
 *  b. If the game state is TFT_DISPLAY_RIGHT, highlights all of the letters in the string of text in
 *  green.
 *  c. If the game state is TFT_DISPLAY_DEFAULT, this highlights nothing.
 */
void
/*
 * Called by:
 *  TFT_init()
 *  TaskFunction_LCD()
 * Calls:
 *  TFT_clear_image()
 *  TFT_load_image_with_array()
 *  EVE_memRead16()
 *  EVE_start_cmd_burst()
 *  EVE_cmd_dl_burst()
 *  EVE_cmd_setbitmap_burst()
 *  EVE_color_rgb_burst()
 *  EVE_cmd_fgcolor_burst()
 *  EVE_cmd_button_burst()
 *  EVE_cmd_rgb_burst()
 *  EVE_cmd_text_burst()
 *  EVE_end_cmd_burst()
 *  strlen()
 *  strcmp()
 *  Clock_Delay1ms()
 * Blocks:
 *  ALL EVE commands are blocking if communication with the LCD is disrupted
 * Input: none
 * Bytes used on the stack: up to 8045 bytes
 * Returns: none
 */
TFT_display() {
	uint16_t space;

	//if going to the next image OR image was flashed recently
	if (b_image_changed) {
		b_image_changed = false;
		TFT_clear_image(0xFFFFF); //clear image in LCD's RAM

		uint32_t flash_addr = (0x1000 * 2 * (g_current_image_index) + (0x20000)
				+ IMAGE_PARAM_BYTES); //calculate flash addr

		//image data buffer
		uint8_t image_buffer[8000];
		int i;
		for (i = 0; i < dictionary[g_current_image_index].image_size; i++) {
			image_buffer[i] = *(uint8_t*) (flash_addr + i);
		}
		TFT_load_image_with_array(image_buffer,
				dictionary[g_current_image_index].image_size); //load new image
	}

	space = EVE_memRead16(REG_CMDB_SPACE); //debug var

	EVE_start_cmd_burst(); /* start writing to the cmd-fifo as one stream of bytes, only sending the address once */

	EVE_cmd_dl_burst(CMD_DLSTART); /* start the display list */
	EVE_cmd_dl_burst(DL_CLEAR_RGB | WHITE); /* set the default clear color to white */
	EVE_cmd_dl_burst(DL_CLEAR | CLR_COL | CLR_STN | CLR_TAG); /* clear the screen - this and the previous prevent artifacts between lists, Attributes are the color, stencil and tag buffers */

	Clock_Delay1ms(2);

	/* display a picture */
	//if png -> EVE_ARGB4
	//if jpg -> EVE_RGB565
	if (strcmp(dictionary[g_current_image_index].image_type, "jpeg") == 0) {
		EVE_cmd_setbitmap_burst(MEM_PIC1, EVE_RGB565,
				dictionary[g_current_image_index].width,
				dictionary[g_current_image_index].height);
	} else {
		EVE_cmd_setbitmap_burst(MEM_PIC1, EVE_ARGB4,
				dictionary[g_current_image_index].width,
				dictionary[g_current_image_index].height);
	}
	EVE_cmd_dl_burst(DL_BEGIN | EVE_BITMAPS);
	EVE_cmd_dl_burst(VERTEX2F(0, 0)); //begin the image at (0, 0)
	EVE_cmd_dl_burst(DL_END); //end this portion of the display list

	Clock_Delay1ms(2);

	//begin constructing the display string of text
	char tft_display_string[11];

	//for every character in the inputted word, add it to the string of text and
	//separate them with a space
	int i = 0;
	for (i = 0; i < strlen(p_input_word); i++) {
		tft_display_string[2 * i] = p_input_word[i];
		tft_display_string[2 * i + 1] = ' ';
	}

	//case where the inputted word has less characters than the correct word
	if (strlen(p_input_word) < strlen(p_correct_word)) {

		//add underscores to the string of text until it matches the correct word
		//in character length, spaces excluded
		int j;
		for (j = i; j < strlen(p_correct_word); j++) {
			tft_display_string[2 * j] = '_';
			tft_display_string[2 * j + 1] = ' ';
		}
		tft_display_string[2 * j] = '\0'; //null terminator to signify string end
	}
	//case where inputted word has at least as many characters as the correct word
	else {
		tft_display_string[2 * i] = '\0'; //null terminator to signify string end
	}

	Clock_Delay1ms(2);

	EVE_cmd_dl_burst(VERTEX_FORMAT(0));

	//highlight word with nothing/red/green
	//also changing button text
	char *button_text = "Check!";
	switch (g_TFT_game_state) {
	case TFT_DEFAULT:
		//highlight nothing
		break;
	case TFT_DISPLAY_WRONG:
		if (strlen(p_input_word) > strlen(p_correct_word)) {
			break; //letters should be red anyways; highlight won't show anything
		} else {
			int i;
			EVE_color_rgb_burst(RED); //set color to red
			int x_location_start = EVE_HSIZE / 2; //default position of string of text is middle of screen
			int x_location_end = 0;
			int total_highlight_length = 0;

			//get total highlighting length by adding up all of the widths in the display string
			for (i = 0; i < strlen(tft_display_string); i++) {
				total_highlight_length += g_font_widths[tft_display_string[i]];
			}

			//calculate start location of highlighting by subtracting half of the
			//total highlighting width from the center of the screen
			x_location_start -= total_highlight_length / 2;

			for (i = 0; i < strlen(p_correct_word); i++) {

				//evaluate the highlighting's ending location
				//this is the starting location added with the next character's width
				x_location_end = x_location_start
						+ g_font_widths[tft_display_string[2 * i]];

				//if the character is wrong, highlight it in red
				if ((i >= strlen(p_input_word)
						|| toupper(p_input_word[i])
								!= toupper(p_correct_word[i]))) {
					EVE_cmd_dl_burst(DL_BEGIN | EVE_RECTS); //make rectangle
					EVE_cmd_dl_burst(LINE_WIDTH(TFT_HIGHLIGHT_HEIGHT*16)); /* size is in 1/16 pixel */

					//highlighting with compactness between the rectangles to distinguish highlighting of
					//nearby wrong letters as well
					EVE_cmd_dl_burst(
							VERTEX2F(
									x_location_start + TFT_HIGHLIGHT_COMPACTNESS_OFFSET,
									200 - TFT_HIGHLIGHT_HEIGHT/2));
					EVE_cmd_dl_burst(
							VERTEX2F(
									x_location_end - TFT_HIGHLIGHT_COMPACTNESS_OFFSET,
									200 + TFT_HIGHLIGHT_HEIGHT/2));

					EVE_cmd_dl_burst(DL_END); //end this display list section
				}

				//update the end location and the next start location
				//the next start location is the current end location
				x_location_end += g_font_widths[tft_display_string[2 * i + 1]];
				x_location_start = x_location_end;
			}
		}
		break;
	case TFT_DISPLAY_RIGHT:
		button_text = "Next >"; //set the touch button's text to "Next >"
		if (true) { // c error?
			//highlight right letters with green
			int i;
			EVE_color_rgb_burst(GREEN); //change color to green
			int x_location_start = EVE_HSIZE / 2; //default position of string is middle of screen
			int x_location_end = 0;
			int total_highlight_length = 0;

			//get total highlighting length by adding up the widths in the display string
			for (i = 0; i < strlen(tft_display_string); i++) {
				total_highlight_length += g_font_widths[tft_display_string[i]];
			}

			//calculate start location of highlighting by subtracting half of the
			//total highlighting width from the center of the screen
			x_location_start -= total_highlight_length / 2;

			for (i = 0; i < strlen(p_correct_word); i++) {

				//evaluate the highlighting's ending location
				//this is the starting location added with the next character's width
				x_location_end = x_location_start
						+ g_font_widths[tft_display_string[2 * i]];

				//highlight all letters green
				EVE_cmd_dl_burst(DL_BEGIN | EVE_RECTS); //make rectangle
				EVE_cmd_dl_burst(LINE_WIDTH(TFT_HIGHLIGHT_HEIGHT*16)); /* size is in 1/16 pixel */
				EVE_cmd_dl_burst(
						VERTEX2F(
								x_location_start + TFT_HIGHLIGHT_COMPACTNESS_OFFSET,
								200 - TFT_HIGHLIGHT_HEIGHT/2));
				EVE_cmd_dl_burst(
						VERTEX2F(
								x_location_end - TFT_HIGHLIGHT_COMPACTNESS_OFFSET,
								200 + TFT_HIGHLIGHT_HEIGHT/2));
				EVE_cmd_dl_burst(DL_END);

				//update the end location and the next start location
				//the next start location is the current end location
				x_location_end += g_font_widths[tft_display_string[2 * i + 1]];
				x_location_start = x_location_end;
			}
		}
		break;
	default:
		//highlight nothing
		break;

	}

	//make button
	EVE_cmd_dl_burst(DL_COLOR_RGB | WHITE);
	EVE_cmd_fgcolor_burst(0x00c0c0c0); /* some grey */
	EVE_cmd_dl_burst(TAG(10)); /* assign tag-value '10' to the button that follows */
	EVE_cmd_button_burst(200, 20, 80, 30, 28, g_toggle_state, button_text);
	EVE_cmd_dl_burst(TAG(0)); /* no touch */

	Clock_Delay1ms(2);

	//if the input character has more characters than the correct word, make the display string red
	if (strlen(p_input_word) > strlen(p_correct_word)) {
		EVE_color_rgb_burst(RED);
	} else {
		EVE_color_rgb_burst(BLACK);
	}

	//add the display string to the screen
	EVE_cmd_text_burst((EVE_HSIZE / 2), 200, FONT, EVE_OPT_CENTER,
			tft_display_string);

	EVE_cmd_dl_burst(DL_DISPLAY); /* instruct the graphics processor to show the list */
	EVE_cmd_dl_burst(CMD_SWAP); /* make this list active */
	EVE_end_cmd_burst();

}

/*
 * The below methods are adapted from GitHub user RudolphRiedel's FT800-FT813 Library.
 *
 Copyright:
 MIT License

 Copyright (c) 2016-2021 Rudolph Riedel

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
 to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

/*
 * Author: Adapted from GitHub user RudolphRiedel
 * Date: 12/26/2021
 * Title of program: tft.c
 * Code version: V5
 * Type of code: source code
 * Web address: https://github.com/RudolphRiedel/FT800-FT813/blob/5.x/examples/EVE_Test_SAME51_EVE3-43G/tft.c
 *
 *
 * Initializes the touch screen with specific parameters. These were taken from GitHub user
 * RudolphRiedel's FT800-FT813 library.
 */
void
/*
 * Called by: TFT_init()
 * Calls:
 *  EVE_memWrite32()
 * Blocks:
 *  EVE_memWrite32() is blocking if communcation with the LCD is disrupted.
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_touch_init() {

#if defined (EVE_NHD_35)
	EVE_memWrite32(REG_TOUCH_TRANSFORM_A, 0x0000f78b);
	EVE_memWrite32(REG_TOUCH_TRANSFORM_B, 0x00000427);
	EVE_memWrite32(REG_TOUCH_TRANSFORM_C, 0xfffcedf8);
	EVE_memWrite32(REG_TOUCH_TRANSFORM_D, 0xfffffba4);
	EVE_memWrite32(REG_TOUCH_TRANSFORM_E, 0x0000f756);
	EVE_memWrite32(REG_TOUCH_TRANSFORM_F, 0x0009279e);
#endif
}

/*
 * Author: Adapted from GitHub user RudolphRiedel
 * Date: 12/26/2021
 * Title of program: tft.c
 * Code version: V5
 * Type of code: source code
 * Web address: https://github.com/RudolphRiedel/FT800-FT813/blob/5.x/examples/EVE_Test_SAME51_EVE3-43G/tft.c
 *
 *
 * Begins the TFT's touch calibration process. This is method is blocking and will prevent other
 * processes from executing.
 */
void
/*
 * Called by: TFT_init()
 * Calls:
 *  EVE_cmd_dl()
 *  EVE_cmd_text()
 *  EVE_cmd_calibrate()
 *  EVE_cmd_execute()
 *  Clock_Delay1us()
 * Blocks:
 *  ALL EVE commands are blocking if communication with the LCD is disrupted.
 * Input: none
 * Bytes used on the stack: 0
 * Returns: none
 */
TFT_recalibrate() {
	/* calibrate touch and displays values to screen */
	EVE_cmd_dl(CMD_DLSTART);
	Clock_Delay1us(50);
	EVE_cmd_dl(DL_CLEAR_RGB | BLACK);
	Clock_Delay1us(50);
	EVE_cmd_dl(DL_CLEAR | CLR_COL | CLR_STN | CLR_TAG);
	Clock_Delay1us(50);
	EVE_cmd_text((EVE_HSIZE / 2), 50, 26, EVE_OPT_CENTER,
			"Please tap on the dot.");
	Clock_Delay1us(50);

	EVE_cmd_calibrate();
	Clock_Delay1us(50);

	EVE_cmd_dl(DL_DISPLAY);
	Clock_Delay1us(50);

	EVE_cmd_dl(CMD_SWAP);
	Clock_Delay1us(50);

	EVE_cmd_execute();
	Clock_Delay1us(50);
}
